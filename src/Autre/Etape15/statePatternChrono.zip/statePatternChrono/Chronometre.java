package statePatternChrono;

public class Chronometre {

	private Etat etatDuSysteme;
	private int etatCpt;
	
	public void setEtat(Etat etat){
		etatDuSysteme = etat;
	}
	
	public Chronometre() {
		this.setEtat(new Reset());
	}
	
	public void pressEspace(){etatDuSysteme.AppuyerSurEspace(this);}
	
	public void pressEntree(){etatDuSysteme.AppuyerSurEntree(this);}
	
	

}
