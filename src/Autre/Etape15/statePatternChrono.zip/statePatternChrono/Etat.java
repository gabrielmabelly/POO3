package statePatternChrono;

public abstract class Etat {

	public abstract void AppuyerSurEspace(Chronometre r);
	public abstract void AppuyerSurEntree(Chronometre r);
}

class Reset extends Etat 
{
	public Reset() {System.out.println("Je suis dans l'état Reset");}
	public void AppuyerSurEspace(Chronometre r){r.setEtat(new Running());};
	public void AppuyerSurEntree(Chronometre r){System.exit(0);};
}

class Stopped extends Etat 
{
	public Stopped() {System.out.println("Je suis en mode Stopped");}
	
	public void AppuyerSurEspace(Chronometre r) {r.setEtat(new Running());};
	public void AppuyerSurEntree(Chronometre r) {r.setEtat(new Running());};
}	

class Running extends Etat {
	
	public Running() {System.out.println("Je suis dans en mode Running");}
	
	public void AppuyerSurEspace(Chronometre r) {r.setEtat(new Stopped());};
	public void AppuyerSurEntree(Chronometre r) {r.setEtat(new Reset());};	
	}

