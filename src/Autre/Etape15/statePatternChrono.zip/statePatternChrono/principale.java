package statePatternChrono;

import java.util.Scanner;

public class principale {

	public static void main(String[] args) 
		{
		Scanner sc = new Scanner(System.in); 
		Chronometre cc = new Chronometre();
		
		char c;
		do {
			System.out.println("Appuyer sur espace ou entrée");
			c = (sc.nextLine()).charAt(0);
			System.out.println("Caractère saisi : " + c);
			if (c == 's') {
				cc.pressEspace();
			}
			if (c == 'e') {
				cc.pressEntree();
			}
		} while (c != 'f');
	}

}
