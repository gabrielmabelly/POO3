package patternCompositeSimpson;

import java.util.ArrayList;

public class Individu extends Foyer {

	public final Personne p2=null; // on fixe p2  
	
	
	public Individu(String Nom,String Prenom,int age) {
		super();
		this.p1 = new Personne(Nom,Prenom,age);
	}

	
	@Override
	public void ajouterAuFoyer(Individu i) {
		// TODO Auto-generated method stub
		System.out.println("Pas possible pour ce type de noeud");
	}

	@Override
	public void retirerDuFoyer(Individu i) {
		// TODO Auto-generated method stub
		System.out.println("Pas possible pour ce type de noeud");
	}

	@Override
	public Famille fonderCouple(Individu i) {
		Famille f = new Famille(this,i);
		return f;
	}

	public Famille fonderFamille(Individu i,ArrayList<Foyer> enfants) {
		Famille f = new Famille(this,i,enfants); 
		// TODO Auto-generated method stub
		return f;
	}

}
