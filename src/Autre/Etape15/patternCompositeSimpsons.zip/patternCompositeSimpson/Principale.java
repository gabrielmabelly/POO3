package patternCompositeSimpson;

import java.util.ArrayList;

public class Principale {

	public static void main(String[] args) {

		
		Individu abraham = new Individu("Simpson","Abraham",87);
		Individu mona = new Individu("Simpson","Mona",87);

		Individu herb = new Individu("Simpson","Herb",55);
		Individu homer = new Individu("Simpson","Homer",51);

		Individu clancy = new Individu("Bouvier","clancy",76);
		Individu jackie = new Individu("Bouvier","Jackie",60);

		Individu marge = new Individu("Bouvier","Marge",42);
		
		Individu patty = new Individu("Bouvier","Patty",23);
		Individu selma = new Individu("Bouvier","Selma",32);

		Individu bart = new Individu("Simpson","Bart",17);
		Individu lisa = new Individu("Simpson","Lisa",12);
		Individu maggie = new Individu("Simpson","Mona",1);

		
		ArrayList<Foyer> childsAbraMona = new ArrayList<Foyer>();
		childsAbraMona.add(herb);
		childsAbraMona.add(homer);
				
		Famille simpsonGP = new Famille(abraham,mona,childsAbraMona);
		
		Famille homerMarge = homer.fonderCouple(marge);
		// supprimer Homer des enfants de AbraetMona
		childsAbraMona.remove(homer);
		childsAbraMona.add(homerMarge);
		
		
	}

}
