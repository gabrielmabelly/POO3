package patternCompositeSimpson;

import java.util.ArrayList;

public class Famille extends Foyer {

	ArrayList<Foyer> enfants;
		
	public Famille(ArrayList<Foyer> enfants) {
		super();
		this.enfants = enfants;
	}

	public Famille() {
		this.enfants = new ArrayList<Foyer>();
	}

	public Famille(Individu i1,Individu i2) {
		this.p1 = i1.p1;
		this.p2 = i2.p1;
		enfants = new ArrayList<Foyer>();
	}
	
	public Famille(Individu i1,Individu i2,ArrayList<Foyer> childs) {
		this.p1 = i1.p1;
		this.p2 = i2.p1;
		enfants = childs;
	}

	
	@Override
	public void ajouterAuFoyer(Individu i) {
// naissance d'un enfant
		enfants.add(i);
	}

	@Override
	public void retirerDuFoyer(Individu i) {
		// TODO Auto-generated method stub
		enfants.add(i);		
	}

	@Override
	public Foyer fonderCouple(Individu i) {
		System.out.println("Pas de sens dans ce cas");
		return null;
	}

	@Override
	public Famille fonderFamille(Individu p, ArrayList<Foyer> enfants) {
		System.out.println("Pas de sens dans ce cas");
		return null;
	}

	
	

}
