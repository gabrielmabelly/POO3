package patternCompositeSimpson;

import java.util.ArrayList;

public abstract class Foyer {
	
	Personne p1;
	Personne p2;

	public abstract void ajouterAuFoyer(Individu i);
	public abstract void retirerDuFoyer(Individu i);
	public abstract Foyer fonderCouple(Individu i);
	public abstract Famille fonderFamille(Individu i,ArrayList<Foyer> enfants);
	
	public Foyer(Personne p1, Personne p2) {
		super();
		this.p1 = p1;
		this.p2 = p2;
	}
	
	public Foyer() {super();}
	
}
